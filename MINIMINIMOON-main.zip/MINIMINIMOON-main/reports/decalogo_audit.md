# Auditoría de decálogos

* **decalogo-industrial** · _info_ · Los indicadores industriales carecen de preguntas explícitas; se crean placeholders.
* **dnp-standards** · _truncated_section_ · Se removió la sección 'circular_economy' por datos incompletos.
* **dnp-standards** · _json_parse_error_ · No fue posible parsear DNP_STANDARDS.json: Expecting property name enclosed in double quotes: line 1069 column 3 (char 40508)
* **dnp-standards** · _evidencia_insuficiente_ · No hay datos estructurados; se crean placeholders.
