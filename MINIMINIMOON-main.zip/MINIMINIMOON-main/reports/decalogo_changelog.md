# Changelog de normalización

- Normalización inicial versión 1.0.0
