# Resultado decalogo-doctor

- Loader: decatalogo_loader
- SHA256 bundle: e2a93e72638042b8c3212d4a8eb512151dca2e0a0467087b8705edf758779891
